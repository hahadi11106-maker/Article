"""Handwritten sorting algorithms. No built-in sort is used by the application."""
from dataclasses import dataclass
from time import perf_counter

class Cancelled(Exception):
    pass

@dataclass
class Metrics:
    comparisons: int = 0
    swaps: int = 0
    writes: int = 0
    milliseconds: float = 0.0

# best / average / worst, stability. Stability refers to equal complete keys.
INFO = {
    'Bubble': ('O(n) / O(n²) / O(n²)', True),
    'Selection': ('O(n²) / O(n²) / O(n²)', False),
    'Insertion': ('O(n) / O(n²) / O(n²)', True),
    'Merge': ('O(n log n) / O(n log n) / O(n log n)', True),
    'Quick': ('O(n log n) / O(n log n) / O(n²)', False),
    'Heap': ('O(n log n) / O(n log n) / O(n log n)', False),
    'Shell': ('O(n log n) / gap-dependent / O(n²)', False),
    'Cocktail': ('O(n) / O(n²) / O(n²)', True),
    'Comb': ('O(n log n) / gap-dependent / O(n²)', False),
    'Gnome': ('O(n) / O(n²) / O(n²)', True),
    'Counting': ('O(n+k) / O(n+k) / O(n+k)', True),
    'Radix': ('O(d(n+b)) / O(d(n+b)) / O(d(n+b))', True),
}

def sort_records(rows, algorithm, keys, cancelled=lambda: False):
    """keys: [(column, descending)]. Numeric distribution sorts need one integer key.
    Timer includes copying, key normalization and sorting, excludes rendering/I/O.
    Swaps count exchanges of distinct array positions. Writes count output/array
    placements (including temporary merge/bucket arrays), not the initial copy.
    Comparisons count key comparisons, not loop/array-bound checks.
    """
    start = perf_counter()
    m = Metrics()
    a = list(rows)
    if algorithm not in INFO or not keys:
        raise ValueError('Choose an algorithm and at least one sort key.')
    def check():
        if cancelled():
            raise Cancelled('Operation cancelled')
    def norm(v):
        return v.casefold() if isinstance(v, str) else v
    # Cache keys before the timed algorithm; this work remains in total elapsed time.
    cached = {id(r): tuple(norm(r[k]) for k, _ in keys) for r in a}
    def cmp(x, y):
        check()
        for i, (_, desc) in enumerate(keys):
            m.comparisons += 1
            u, v = cached[id(x)][i], cached[id(y)][i]
            c = (u > v) - (u < v)
            if c:
                return -c if desc else c
        return 0
    def swap(i, j):
        if i != j:
            a[i], a[j] = a[j], a[i]
            m.swaps += 1
            m.writes += 2
    def put(i, v):
        a[i] = v
        m.writes += 1
    n = len(a)
    check()
    if algorithm == 'Bubble':
        for end in range(n - 1, 0, -1):
            changed = False
            for i in range(end):
                if cmp(a[i], a[i+1]) > 0:
                    swap(i, i+1); changed = True
            if not changed: break
    elif algorithm == 'Selection':
        for i in range(n):
            p = i
            for j in range(i+1, n):
                if cmp(a[j], a[p]) < 0: p = j
            swap(i, p)
    elif algorithm in ('Insertion', 'Shell'):
        gaps = [1]
        if algorithm == 'Shell':
            gaps = []; gap = n // 2
            while gap:
                gaps.append(gap); gap //= 2
        for gap in gaps:
            for i in range(gap, n):
                value, j = a[i], i
                while j >= gap and cmp(a[j-gap], value) > 0:
                    put(j, a[j-gap]); j -= gap
                put(j, value)
    elif algorithm == 'Merge':
        width = 1
        while width < n:
            for lo in range(0, n, 2*width):
                mid, hi = min(lo+width, n), min(lo+2*width, n)
                left, right, out = lo, mid, []
                while left < mid and right < hi:
                    if cmp(a[left], a[right]) <= 0:
                        out.append(a[left]); left += 1
                    else:
                        out.append(a[right]); right += 1
                    m.writes += 1
                out.extend(a[left:mid]); out.extend(a[right:hi])
                m.writes += mid-left + hi-right
                for j, v in enumerate(out, lo): put(j, v)
            width *= 2
    elif algorithm == 'Quick':
        stack = [(0, n-1)]
        while stack:
            lo, hi = stack.pop()
            if lo >= hi: continue
            pivot = a[(lo+hi)//2]
            i, j = lo, hi
            while i <= j:
                while cmp(a[i], pivot) < 0: i += 1
                while cmp(a[j], pivot) > 0: j -= 1
                if i <= j:
                    swap(i, j); i += 1; j -= 1
            if lo < j: stack.append((lo, j))
            if i < hi: stack.append((i, hi))
    elif algorithm == 'Heap':
        def sift(root, size):
            while 2*root+1 < size:
                child = 2*root+1
                if child+1 < size and cmp(a[child], a[child+1]) < 0: child += 1
                if cmp(a[root], a[child]) >= 0: break
                swap(root, child); root = child
        for i in range(n//2-1, -1, -1): sift(i, n)
        for end in range(n-1, 0, -1):
            swap(0, end); sift(0, end)
    elif algorithm == 'Cocktail':
        lo, hi = 0, n-1
        while lo < hi:
            changed = False
            for i in range(lo, hi):
                if cmp(a[i], a[i+1]) > 0:
                    swap(i, i+1); changed = True
            hi -= 1
            if not changed: break
            changed = False
            for i in range(hi, lo, -1):
                if cmp(a[i-1], a[i]) > 0:
                    swap(i-1, i); changed = True
            lo += 1
            if not changed: break
    elif algorithm == 'Comb':
        gap, changed = n, True
        while gap > 1 or changed:
            gap = max(1, int(gap/1.3)); changed = False
            for i in range(n-gap):
                if cmp(a[i], a[i+gap]) > 0:
                    swap(i, i+gap); changed = True
    elif algorithm == 'Gnome':
        i = 1
        while i < n:
            if i == 0 or cmp(a[i-1], a[i]) <= 0: i += 1
            else: swap(i-1, i); i -= 1
    else:
        if len(keys) != 1 or any(not isinstance(r[keys[0][0]], int) for r in a):
            raise ValueError('Counting and Radix require a single integer column.')
        if a:
            col, desc = keys[0]
            vals = [(-r[col] if desc else r[col]) for r in a]
            low = high = vals[0]
            for v in vals[1:]:
                check(); m.comparisons += 2
                if v < low: low = v
                if v > high: high = v
            if algorithm == 'Counting':
                if high-low > 1_000_000:
                    raise ValueError('Counting range exceeds 1,000,000; use Radix.')
                buckets = [[] for _ in range(high-low+1)]
                for r, v in zip(a, vals):
                    check(); buckets[v-low].append(r); m.writes += 1
                a = [r for b in buckets for r in b]; m.writes += n
            else:
                exp = 1
                while (high-low)//exp > 0:
                    buckets = [[] for _ in range(10)]
                    for r in a:
                        check()
                        v = (-r[col] if desc else r[col])-low
                        buckets[(v//exp)%10].append(r); m.writes += 1
                    a = [r for b in buckets for r in b]; m.writes += n
                    exp *= 10
    check()
    m.milliseconds = (perf_counter()-start)*1000
    return a, m
