"""Case-insensitive filters and handwritten exact binary search."""
from time import perf_counter
from algorithms import sort_records
from data_layer import COLUMNS, NUMERIC
OPS = ['contains','starts with','ends with','equals','not equals','>','>=','<','<=']

def filter_rows(rows, clauses, join='AND'):
    """All clauses use selected global AND/OR; each can be negated separately."""
    if join not in ('AND','OR'): raise ValueError('Join must be AND or OR.')
    compiled = []
    for col, op, value, negate in clauses:
        if col not in COLUMNS or op not in OPS: raise ValueError('Invalid filter.')
        if col in NUMERIC:
            if op in ('contains','starts with','ends with'):
                raise ValueError('Use equals or a comparison for numeric columns.')
            value = int(value)
        else: value = str(value).casefold()
        compiled.append((col,op,value,negate))
    def matches(row, clause):
        col,op,target,negate = clause
        v = row[col] if col in NUMERIC else row[col].casefold()
        if op == 'contains': result = target in v
        elif op == 'starts with': result = v.startswith(target)
        elif op == 'ends with': result = v.endswith(target)
        elif op == 'equals': result = v == target
        elif op == 'not equals': result = v != target
        elif op == '>': result = v > target
        elif op == '>=': result = v >= target
        elif op == '<': result = v < target
        else: result = v <= target
        return not result if negate else result
    t = perf_counter()
    output = [r for r in rows if not compiled or
              (all(matches(r,c) for c in compiled) if join == 'AND' else any(matches(r,c) for c in compiled))]
    return output, (perf_counter()-t)*1000

def binary_search(rows, col, value):
    value = int(value) if col in NUMERIC else str(value).casefold()
    start = perf_counter()
    ordered, metrics = sort_records(rows, 'Merge', [(col,False)])
    prep = (perf_counter()-start)*1000
    t = perf_counter(); comparisons = 0
    def key(r): return r[col] if col in NUMERIC else r[col].casefold()
    def bound(upper):
        nonlocal comparisons
        lo, hi = 0, len(ordered)
        while lo < hi:
            mid = (lo+hi)//2; comparisons += 1
            v = key(ordered[mid])
            if v < value or (upper and v == value): lo = mid+1
            else: hi = mid
        return lo
    low, high = bound(False), bound(True)
    result = ordered[low:high]
    return result, {'index_ms':prep,'lookup_ms':(perf_counter()-t)*1000,
                    'comparisons':comparisons, 'index_comparisons':metrics.comparisons}
