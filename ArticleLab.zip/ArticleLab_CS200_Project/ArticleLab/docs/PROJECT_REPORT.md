# ArticleLab: Journal Article Explorer
## CS200 — Data Structure & Algorithms, Project 1, Fall 2026

Student name: [Enter your name]  
Student ID: [Enter your ID]  
Section: [Enter your section]  
Instructor in supplied brief: Nazeef Ul Haq  
Submission deadline in supplied brief: 18 October 2026

## 1. Objective

Build an interactive desktop system that makes sorting and searching behavior
observable on a real dataset of at least 15,000 journal articles. Users compare
algorithms by elapsed time, key comparisons, swaps and writes, and explore records
through composite filters and prioritized sort keys.

## 2. Requirements traceability

| Guideline | Implementation | Qualification |
|---|---|---|
| Individual project | Self-contained Python source and report | Student must personalize and understand the submission |
| At least 15,000 entities | Bundled Europe PMC metadata database and CSV | See manifest for independently counted total |
| At least 8 attributes | 11 fields | Optional upstream fields can be blank |
| Start, pause, resume, stop | Collector controls, events and durable SQLite cursor | In-flight requests have a 30-second timeout |
| Progress count/bar | Page-level progress signals | Updates after page commit |
| URL input bonus | Editable Europe PMC search URL | Not a general-purpose website scraper |
| Python UI, preferably PyQt | PyQt6 desktop interface | Requires Python and PyQt6 |
| List chosen entities | Virtual table model, one row per article | Full data in memory; cells rendered on demand |
| Sort any column | Ten comparison sorts support all fields | Two distribution sorts restricted to one integer field |
| Class algorithms plus two extras | Twelve algorithms | Exact class syllabus was not supplied |
| Time, comparisons, swaps | Metrics for each sort | Writes included for fairer interpretation |
| Complexity and stability | Algorithm selector and benchmark table | Complete-key stability; normalized text comparisons |
| Benchmark all | Same snapshot passed to every applicable algorithm | N/A shown for domain restrictions |
| Full/filtered scope | Scope selector | Full sort reapplies active filter |
| Search any column | Linear filters and binary exact search | Binary search includes index preparation |
| String filters | Contains / starts with / ends with | Case-insensitive |
| Multi-level sorting | Ordered list of column/direction pairs | Comparison algorithms use lexicographic comparison |
| Composite filters | Global AND or OR and per-clause NOT | Nested arbitrary Boolean groups are not implemented |

**Assignment ambiguity:** The brief says “scrapping.” The implementation collects
structured metadata through an official API. This is reliable data collection but
is not HTML parsing. Instructor confirmation is needed if literal HTML scraping
is mandatory. The supplied brief mentions a rubric without supplying a separate
rubric; no additional scoring criteria have been assumed.

## 3. Architecture and data structures

The presentation layer (`app.py`) owns widgets and the table model. Background
QThread jobs perform collection, sorting and benchmarking. Qt signals return data
and progress to the main thread. Controls that mutate the dataset are disabled
while work runs, so operations see a consistent snapshot. Workers never edit UI
widgets directly.

The algorithm layer (`algorithms.py`) accepts a list of record dictionaries and a
sequence of `(column, descending)` keys. A cache stores normalized keys. The
comparison routine checks keys in priority order and stops at the first unequal
pair. Each algorithm returns a fresh ordered list and a Metrics object.

The search layer (`searching.py`) compiles typed clauses and scans rows with AND,
OR and per-clause negation. Binary search first builds a sorted index using the
handwritten Merge algorithm and uses two boundary searches to include duplicates.

The persistence layer (`data_layer.py`) stores metadata in SQLite. Lists provide
constant-time indexing for sorting; dictionaries provide named field access;
Quick uses an explicit stack; Merge uses temporary lists; Counting and Radix use
bucket lists. The database primary key provides uniqueness across restarts.

Data flow: public API -> parsed JSON -> normalized article fields -> transactional
SQLite page/checkpoint -> in-memory records -> filtering/sorting -> table or CSV.

## 4. Entity schema

| Field | Type | Meaning |
|---|---|---|
| article_id | String | Identifier within a source |
| title | String | Publication title |
| authors | String | Author display string |
| journal | String | Journal title |
| year | Integer | Publication year; zero if absent |
| citations | Integer | Citation count at collection time; zero if absent |
| doi | String | DOI, if supplied |
| source | String | Provider source code |
| open_access | String | Upstream open-access flag |
| first_publication_date | String | ISO-style first publication date, if supplied |
| pmcid | String | PubMed Central identifier, if supplied |

Identity is the pair `(source, article_id)`, not DOI: some records have no DOI.
Empty strings are used for absent optional text. Numeric and text fields retain
different comparison behavior. ISO-formatted dates can be sorted lexicographically;
blank dates come first ascending and last descending.

## 5. Algorithm design

Bubble and Cocktail use adjacent swaps with early exit. Selection chooses the
minimum remaining record each pass. Insertion shifts a growing ordered prefix.
Shell applies insertion passes at halving gaps. Comb shrinks its comparison gap
by a factor of 1.3. Gnome steps backward after each inverted adjacent pair.

Merge iteratively combines ordered runs and chooses the left record on a tie.
Quick partitions around a middle-position pivot and uses an explicit stack to
avoid Python recursion limits. Heap constructs a max heap then removes maxima.
Counting groups records by offset integer key; Radix uses stable decimal LSD
passes over nonnegative offsets. Descending distribution sorting transforms keys
before grouping, rather than reversing the final list and breaking tie stability.

Bubble, Insertion, Merge, Cocktail, Gnome, Counting and Radix are stable here.
Selection, Quick, Heap, Shell and Comb are not. These properties describe the
implementations, not merely algorithm names. Built-in sorted/list.sort are not
used by application sorting; tests use sorted as an independent expected-result
oracle.

For n records, Merge and Heap guarantee O(n log n) sorting time. Quick averages
O(n log n) but can reach O(n²). Bubble, Selection, Insertion, Cocktail and Gnome
can reach O(n²). Shell and Comb depend on gap choices and have O(n²) worst cases
for the implemented variants. Counting is O(n+k), where k is key range; Radix is
O(d(n+b)), where d is digits and b=10. All application runs additionally use an
O(n) copied list and O(n*m) normalized key cache for m sort keys. Merge and
bucket algorithms add temporary storage; do not claim the whole application is
in-place simply because a core algorithm can be.

## 6. Collection and recovery

The first request uses cursor `*`; later requests use the server's next cursor.
Page size is at most 1,000 and is bounded by the remaining target. Each response
is normalized before a transaction inserts unique articles and advances the
checkpoint. A crash before commit repeats the page; a crash after commit resumes
at the next page. INSERT OR IGNORE handles duplicates. The database also records
the query, URL, last-update timestamp and exhaustion status.

Pause clears an event; Resume sets it. Stop sets a stop event and releases a
paused worker. A page received while paused is held until resume; a page received
after stop is discarded. Committed records are never removed by these controls.
Retries use bounded exponential delays. Endpoint validation restricts collection
to the supported HTTPS Europe PMC API; it does not bypass authentication or site
restrictions.

## 7. Experimental method and results

`benchmark_500.csv` reports an actual run of all 12 algorithms on the same first
500 records, sorting citations ascending. `benchmark_full.csv` reports selected
efficient algorithms on all 15,000 records. These are separate experiments;
results must not be compared as if their input sizes were equal. Full-data
quadratic algorithms are available in the UI but are not represented as measured
in the bundled full-data CSV.

Each benchmark begins with the same input order. The timer includes copy and key
normalization overhead. Results include comparisons, swaps and writes. No average
or confidence interval is claimed from these single runs. For a stronger lab
study, repeat five times on shuffled, already ordered and reverse-ordered inputs,
report median elapsed time, and record machine specifications.

Comparisons are not the same amount of CPU work for every algorithm. Counting
and Radix do arithmetic and placement without pairwise order comparisons. Merge
can report zero swaps while making many writes. Stability should be evaluated
using duplicate keys and original row identities.

## 8. Validation and limitations

The executed validation record is in `VALIDATION.txt`. Unit tests check all
algorithms on empty, singleton, duplicate, ascending, descending and random
integer inputs in both directions, stable tie behavior, string/multiple keys,
cancellation and distribution-domain rejection. Search tests cover Boolean
filters and duplicate/missing binary matches. Collector tests cover atomic
checkpoint continuation, deduplication, query isolation, URL rejection and event
controls. CSV round-tripping preserves quoted text and newlines.

The offscreen desktop test loads the real dataset, searches, sorts, benchmarks
all 12 algorithms on a small subset, captures the interface and closes cleanly.
This is a Linux headless check, not a claim of manual Windows installation testing.

Limits: API collection rather than HTML parsing; endpoint-specific URL bonus;
no nested Boolean groups; binary indexes are rebuilt; optional metadata may be
missing; full-data quadratic algorithms can be slow; API ordering and citation
counts can change over time; long-lived cursors depend on upstream behavior.
Imported CSVs are in-memory views and do not replace the collector database.
The exact class algorithm list and student identifying details remain to be filled
in by the student.

## 9. Demonstration and viva preparation

1. Launch the app and show the loaded record count and eleven columns.
2. Search titles containing “cancer”; add year >= 2020 with AND.
3. Negate the year clause and explain NOT; switch to OR and explain the change.
4. Sort by citations descending and title ascending; explain key priority.
5. Compare Merge and Quick on the same subset. Explain stability and counters.
6. Benchmark all algorithms on a small filtered subset and export the result.
7. Use binary equals on a year; explain index preparation and duplicate bounds.
8. Choose a new database, start collection, pause, resume, stop, then restart.
9. Export visible rows and import the CSV again.

Questions to prepare: Why can Merge have zero swaps? Why is binary search not
O(log n) end-to-end when building its index? Why does stable descending Radix
avoid reversing the final records? Why must cursor and rows commit together?
Why are Counting/Radix N/A for titles? Why is a duplicate-aware primary key needed?
What would be changed to support literal HTML scraping or nested Boolean filters?

## 10. References and acknowledgments

Assignment source: Project_1_Guidelines_Fall_2026.pdf supplied by the user.
Europe PMC RESTful Web Service: https://europepmc.org/RestfulWebService
Europe PMC API reference: https://europepmc.org/docs/EBI_Europe_PMC_Web_Service_Reference.pdf
PyQt6 documentation: https://www.riverbankcomputing.com/static/Docs/PyQt6/
Python sqlite3 documentation: https://docs.python.org/3/library/sqlite3.html

Implementation and documentation were prepared with AI assistance. Revise this
acknowledgment to match your course's disclosure requirements and describe your
own changes and understanding. Do not present unperformed experiments as results.
