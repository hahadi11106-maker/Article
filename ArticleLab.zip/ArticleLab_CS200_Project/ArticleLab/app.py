"""ArticleLab: PyQt6 desktop application. Run: python app.py"""
import sys
import csv
import threading
from pathlib import Path
from PyQt6.QtCore import Qt, QAbstractTableModel, QThread, pyqtSignal
from PyQt6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,
    QLabel,QPushButton,QComboBox,QLineEdit,QSpinBox,QProgressBar,QTabWidget,QTableView,
    QTableWidget,QTableWidgetItem,QCheckBox,QFileDialog,QMessageBox,QHeaderView,QTextBrowser)
from algorithms import INFO, sort_records, Cancelled
from data_layer import COLUMNS, NUMERIC, DEFAULT_DB, DEFAULT_URL, Collector, load_rows, export_csv, import_csv
from searching import OPS, filter_rows, binary_search

class TableModel(QAbstractTableModel):
    def __init__(self, rows): super().__init__(); self.rows = rows
    def rowCount(self, parent=None): return len(self.rows)
    def columnCount(self, parent=None): return len(COLUMNS)
    def data(self,index,role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid(): return None
        if role in (Qt.ItemDataRole.DisplayRole, Qt.ItemDataRole.ToolTipRole):
            return str(self.rows[index.row()][COLUMNS[index.column()]])
    def headerData(self,section,orientation,role):
        if role == Qt.ItemDataRole.DisplayRole:
            return COLUMNS[section].replace('_',' ').title() if orientation == Qt.Orientation.Horizontal else str(section+1)
    def replace(self, rows):
        self.beginResetModel(); self.rows = rows; self.endResetModel()

class Task(QThread):
    result = pyqtSignal(object)
    error = pyqtSignal(str)
    progress = pyqtSignal(int,str)
    def __init__(self, fn): super().__init__(); self.fn = fn
    def run(self):
        try: self.result.emit(self.fn(self))
        except Exception as exc: self.error.emit(str(exc))

def combo(items):
    w = QComboBox(); w.addItems(items); return w

def button(text, fn, layout):
    w = QPushButton(text); w.clicked.connect(fn); layout.addWidget(w); return w

def row_layout(parent):
    row = QHBoxLayout(); parent.addLayout(row); return row

class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('ArticleLab | CS200 Data Structures & Algorithms')
        self.resize(1320,880)
        self.db = DEFAULT_DB
        self.rows = load_rows(self.db); self.visible = list(self.rows)
        self.active_filter = None; self.task = None; self.collector = None
        self.cancelled = threading.Event()
        root = QWidget(); self.setCentralWidget(root); layout = QVBoxLayout(root)
        heading = QLabel('ArticleLab'); heading.setObjectName('hero'); layout.addWidget(heading)
        layout.addWidget(QLabel('Explore scholarly articles • Compare algorithms • Measure performance'))
        self.count = QLabel(); layout.addWidget(self.count)
        self.tabs = QTabWidget(); layout.addWidget(self.tabs)
        self.build_explorer(); self.build_collection(); self.build_benchmark(); self.build_help()
        status = row_layout(layout)
        self.status = QLabel('Ready'); self.status.setWordWrap(True); status.addWidget(self.status,1)
        self.cancel_button = button('Cancel computation', self.cancel_work, status); self.cancel_button.setEnabled(False)
        self.update_count()

    def page(self, name):
        widget = QWidget(); lay = QVBoxLayout(widget); self.tabs.addTab(widget,name); return widget,lay

    def build_explorer(self):
        self.explorer, lay = self.page('01  Explore & sort')
        r = row_layout(lay)
        button('Import CSV', self.import_data,r); button('Export visible CSV', self.export_data,r)
        button('Reload database', self.reload,r); r.addStretch()
        self.scope = combo(['Filtered results','Full dataset']); r.addWidget(QLabel('Sort / benchmark scope')); r.addWidget(self.scope)
        lay.addWidget(QLabel('Filter clauses — select AND / OR; NOT negates an individual clause. Blank values are ignored.'))
        self.filters = QTableWidget(0,4); self.filters.setHorizontalHeaderLabels(['Column','Operator','Value','NOT'])
        self.filters.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.filters.setMaximumHeight(170); lay.addWidget(self.filters)
        self.add_filter()
        r = row_layout(lay)
        button('+ Filter',self.add_filter,r); button('Remove last',self.remove_filter,r)
        self.join = combo(['AND','OR']); r.addWidget(self.join)
        self.search_method = combo(['Linear filter','Binary exact (one clause)']); r.addWidget(self.search_method)
        button('Apply search',self.search,r); button('Clear search',self.clear_search,r); r.addStretch()
        lay.addWidget(QLabel('Sort keys — top row has highest priority. Click a table header to select one column.'))
        self.keys = QTableWidget(0,2); self.keys.setHorizontalHeaderLabels(['Column','Direction'])
        self.keys.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.keys.setMaximumHeight(125); lay.addWidget(self.keys); self.add_key()
        r = row_layout(lay)
        button('+ Sort key',self.add_key,r); button('Remove last key',self.remove_key,r)
        self.algorithm = combo(list(INFO)); self.algorithm.setCurrentText('Merge'); r.addWidget(self.algorithm)
        button('Sort',self.sort,r)
        button('Benchmark all', self.benchmark,r); r.addStretch()
        self.complexity = QLabel(); lay.addWidget(self.complexity)
        self.algorithm.currentTextChanged.connect(self.update_complexity); self.update_complexity()
        self.model = TableModel(self.visible); self.table = QTableView(); self.table.setModel(self.model)
        self.table.setAlternatingRowColors(True); self.table.setWordWrap(False)
        self.table.setColumnWidth(1,430); self.table.setColumnWidth(2,240); self.table.setColumnWidth(3,210)
        self.table.horizontalHeader().sectionClicked.connect(self.header_clicked)
        lay.addWidget(self.table,1)

    def build_collection(self):
        self.collection_page, lay = self.page('02  Collect articles')
        text = QLabel('Collect real metadata from the Europe PMC API. Start also resumes the durable checkpoint.\n'
            'An existing database is bound to its original query. Choose a new database for another query.\n'
            'Pause and Stop act at request boundaries; an active request may take up to 30 seconds.')
        text.setWordWrap(True); lay.addWidget(text)
        lay.addWidget(QLabel('Source URL (Europe PMC search endpoint only)'))
        self.url = QLineEdit(DEFAULT_URL); lay.addWidget(self.url)
        r = row_layout(lay); r.addWidget(QLabel('Target total unique articles'))
        self.target = QSpinBox(); self.target.setRange(1,1000000); self.target.setValue(15000); r.addWidget(self.target)
        self.db_button = button('Choose database…',self.choose_database,r)
        self.db_label = QLabel(str(self.db)); lay.addWidget(self.db_label)
        r = row_layout(lay)
        self.start_button = button('Start / resume checkpoint',self.collect,r)
        self.pause_button = button('Pause',self.pause_collection,r)
        self.resume_button = button('Resume',self.resume_collection,r)
        self.stop_button = button('Stop',self.stop_collection,r)
        for b in (self.pause_button,self.resume_button,self.stop_button): b.setEnabled(False)
        self.progress = QProgressBar(); lay.addWidget(self.progress)
        self.collection_status = QLabel('Ready'); lay.addWidget(self.collection_status)
        lay.addStretch()

    def build_benchmark(self):
        self.benchmark_page, lay = self.page('03  Benchmark results')
        lay.addWidget(QLabel('Every algorithm receives the same input snapshot. Times include copy/key preparation; UI and I/O are excluded.'))
        lay.addWidget(QLabel('Quadratic algorithms can take minutes on 15,000 rows. Cancel retains completed rows. No hidden sampling.'))
        self.bench = QTableWidget(0,8)
        self.bench.setHorizontalHeaderLabels(['Algorithm','Time (ms)','Comparisons','Swaps','Writes','Stable','Best / average / worst','Status'])
        self.bench.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        lay.addWidget(self.bench)
        r = row_layout(lay); button('Export benchmark CSV',self.export_benchmark,r); r.addStretch()

    def build_help(self):
        _, lay = self.page('04  Project guide')
        helpbox = QTextBrowser()
        helpbox.setHtml('''<h1>ArticleLab</h1><p>CS200 individual project • Fall 2026</p>
        <h2>Quick demonstration</h2><ol><li>Explore the included real article dataset.</li>
        <li>Filter journal using “contains”, then add year ≥ 2020 with AND.</li>
        <li>Sort citations descending using Merge and inspect the metrics.</li>
        <li>Add year as the first key and title as the second key.</li>
        <li>Benchmark a small filtered subset; then test the full dataset if time allows.</li>
        <li>Select a new database and demonstrate collection, Pause, Resume, Stop and restart.</li></ol>
        <h2>Searching</h2><p>Linear filtering supports multiple columns, AND / OR, and per-clause NOT.
        Binary search requires exactly one non-negated equality condition. A handwritten Merge sort
        builds its index; preparation and lookup times are reported separately.</p>
        <h2>Metrics</h2><p>A comparison is a key comparison. Multi-key comparisons count each examined key.
        A swap exchanges two distinct array positions. Writes count placements, including temporary arrays.
        Merge and distribution algorithms may perform zero swaps while writing many records.</p>
        <h2>Distribution sorts</h2><p>Counting and Radix accept one integer column (year or citations).
        Incompatible benchmark rows are explicitly marked N/A. No implicit replacement algorithm is used.</p>
        <h2>Data provenance and assignment caveat</h2><p>Records are retrieved through the documented Europe PMC
        API, not HTML scraping. Confirm that API collection is acceptable to your instructor.
        Optional DOI or PMC fields may be blank; missing numeric values are normalized to zero.</p>
        <p>See README.md and docs/PROJECT_REPORT.md for architecture, test instructions, requirement mapping,
        source attribution, limitations, and viva preparation. Add your own name and student ID before submission.</p>''')
        lay.addWidget(helpbox)

    def update_count(self): self.count.setText(f'{len(self.rows):,} loaded articles   /   {len(self.visible):,} visible   /   11 attributes')
    def refresh(self): self.model.replace(self.visible); self.update_count()
    def update_complexity(self):
        complexity, stable = INFO[self.algorithm.currentText()]
        self.complexity.setText(f'Best / average / worst: {complexity}    |    Stable: {"Yes" if stable else "No"}')
    def add_filter(self):
        i = self.filters.rowCount(); self.filters.insertRow(i)
        self.filters.setCellWidget(i,0,combo(COLUMNS)); self.filters.cellWidget(i,0).setCurrentText('title')
        self.filters.setCellWidget(i,1,combo(OPS)); self.filters.setCellWidget(i,2,QLineEdit())
        self.filters.setCellWidget(i,3,QCheckBox())
    def remove_filter(self):
        if self.filters.rowCount(): self.filters.removeRow(self.filters.rowCount()-1)
    def add_key(self):
        i = self.keys.rowCount(); self.keys.insertRow(i)
        self.keys.setCellWidget(i,0,combo(COLUMNS)); self.keys.cellWidget(i,0).setCurrentText('citations' if i == 0 else 'title')
        self.keys.setCellWidget(i,1,combo(['Ascending','Descending']))
    def remove_key(self):
        if self.keys.rowCount()>1: self.keys.removeRow(self.keys.rowCount()-1)
    def header_clicked(self,i):
        self.keys.setRowCount(0); self.add_key(); self.keys.cellWidget(0,0).setCurrentText(COLUMNS[i])
        self.status.setText('Selected '+COLUMNS[i]+'; choose direction / algorithm and press Sort.')
    def sort_keys(self):
        return [(self.keys.cellWidget(i,0).currentText(),self.keys.cellWidget(i,1).currentText()=='Descending') for i in range(self.keys.rowCount())]
    def clauses(self):
        return [(self.filters.cellWidget(i,0).currentText(),self.filters.cellWidget(i,1).currentText(),
                 self.filters.cellWidget(i,2).text().strip(),self.filters.cellWidget(i,3).isChecked())
                for i in range(self.filters.rowCount()) if self.filters.cellWidget(i,2).text().strip()]
    def report_error(self,message): self.status.setText(message); QMessageBox.warning(self,'ArticleLab',message)
    def busy(self, value, collection=False):
        self.explorer.setEnabled(not value); self.benchmark_page.setEnabled(not value)
        self.start_button.setEnabled(not value); self.db_button.setEnabled(not value)
        self.url.setEnabled(not value); self.target.setEnabled(not value)
        self.cancel_button.setEnabled(value and not collection)
        for b in (self.pause_button,self.stop_button): b.setEnabled(value and collection)
        self.resume_button.setEnabled(False)
    def run_task(self,fn,done,collection=False):
        if self.task and self.task.isRunning(): return
        self.cancelled.clear(); self.busy(True,collection)
        self.task = Task(fn); self.task.result.connect(done); self.task.error.connect(self.report_error)
        self.task.finished.connect(self.task_finished); self.task.start()
    def task_finished(self):
        self.busy(False)
        if self.collector:
            self.collector = None; self.reload()
    def cancel_work(self): self.cancelled.set(); self.status.setText('Cancelling…')
    def search(self):
        clauses, join = self.clauses(), self.join.currentText()
        method = self.search_method.currentText()
        if method.startswith('Binary') and (len(clauses)!=1 or clauses[0][1]!='equals' or clauses[0][3]):
            self.report_error('Binary search needs one equals clause without NOT.'); return
        data = list(self.rows)
        def work(_):
            if method.startswith('Binary'): return binary_search(data,clauses[0][0],clauses[0][2])
            return filter_rows(data,clauses,join)
        def done(result):
            self.visible, metrics = result; self.active_filter = (clauses,join); self.refresh()
            if isinstance(metrics,dict):
                self.status.setText(f'Binary index: {metrics["index_ms"]:.3f} ms | Lookup: {metrics["lookup_ms"]:.3f} ms | Lookup comparisons: {metrics["comparisons"]}')
            else: self.status.setText(f'Linear filter: {metrics:.3f} ms | {len(self.visible):,} matches')
        self.run_task(work,done)
    def clear_search(self): self.active_filter=None; self.visible=list(self.rows); self.refresh(); self.status.setText('Search cleared')
    def sort(self):
        scope, keys, name = self.scope.currentText(),self.sort_keys(),self.algorithm.currentText()
        data = list(self.rows if scope=='Full dataset' else self.visible)
        def done(result):
            ordered,m = result
            if scope=='Full dataset':
                self.rows = ordered
                self.visible = filter_rows(self.rows,*self.active_filter)[0] if self.active_filter else list(self.rows)
            else: self.visible = ordered
            self.refresh()
            self.status.setText(f'{name} | {len(data):,} rows | {m.milliseconds:.3f} ms | {m.comparisons:,} comparisons | {m.swaps:,} swaps | {m.writes:,} writes')
        self.status.setText('Sorting…')
        self.run_task(lambda _:sort_records(data,name,keys,self.cancelled.is_set),done)
    def benchmark(self):
        keys = self.sort_keys(); data = list(self.rows if self.scope.currentText()=='Full dataset' else self.visible)
        self.bench.setRowCount(0); self.tabs.setCurrentWidget(self.benchmark_page)
        # A dedicated signal carries each completed row on the GUI thread.
        def work(task):
            for name,(complexity,stable) in INFO.items():
                if self.cancelled.is_set(): break
                try:
                    _,m = sort_records(data,name,keys,self.cancelled.is_set)
                    values = [name,f'{m.milliseconds:.3f}',str(m.comparisons),str(m.swaps),str(m.writes),str(stable),complexity,'Complete']
                except Cancelled: break
                except ValueError as e: values = [name,'—','—','—','—',str(stable),complexity,'N/A: '+str(e)]
                # JSON gives the existing typed progress signal a structured payload.
                import json
                task.progress.emit(0,json.dumps(values))
            return 'Benchmark cancelled; completed rows retained.' if self.cancelled.is_set() else f'Benchmark complete on {len(data):,} identical input rows.'
        self.cancelled.clear(); self.busy(True); self.status.setText('Benchmark running…')
        self.task = Task(work)
        self.task.progress.connect(self.benchmark_row)
        self.task.result.connect(self.status.setText); self.task.error.connect(self.report_error)
        self.task.finished.connect(self.task_finished); self.task.start()
    def benchmark_row(self,_,payload):
        import json
        values=json.loads(payload); i=self.bench.rowCount(); self.bench.insertRow(i)
        for j,v in enumerate(values): self.bench.setItem(i,j,QTableWidgetItem(v))
        self.status.setText('Benchmark: '+values[0]+' finished')
    def export_benchmark(self):
        path,_ = QFileDialog.getSaveFileName(self,'Export benchmark','benchmark.csv','CSV (*.csv)')
        if path:
            try:
                with open(path,'w',newline='',encoding='utf-8-sig') as f:
                    w=csv.writer(f); w.writerow([self.bench.horizontalHeaderItem(j).text() for j in range(self.bench.columnCount())])
                    for i in range(self.bench.rowCount()): w.writerow([self.bench.item(i,j).text() for j in range(self.bench.columnCount())])
            except OSError as e: self.report_error(str(e))
    def reload(self):
        try: self.rows=load_rows(self.db); self.clear_search()
        except Exception as e: self.report_error(str(e))
    def import_data(self):
        path,_=QFileDialog.getOpenFileName(self,'Import article CSV','','CSV (*.csv)')
        if path:
            try: self.rows=import_csv(path); self.clear_search(); self.status.setText('Imported CSV in memory; collection database unchanged.')
            except Exception as e: self.report_error(str(e))
    def export_data(self):
        path,_=QFileDialog.getSaveFileName(self,'Export visible articles','articles.csv','CSV (*.csv)')
        if path:
            try: export_csv(self.visible,path); self.status.setText('Exported '+str(len(self.visible))+' rows')
            except Exception as e: self.report_error(str(e))
    def choose_database(self):
        path,_=QFileDialog.getSaveFileName(self,'Choose existing or new database',str(self.db),'SQLite (*.db)',options=QFileDialog.Option.DontConfirmOverwrite)
        if path:
            self.db=Path(path); self.db_label.setText(str(self.db)); self.reload()
    def collect(self):
        self.collector=Collector(self.db); url=self.url.text(); target=self.target.value()
        self.progress.setRange(0,target)
        def work(task): return self.collector.run(url,target,task.progress.emit)
        def done(n): self.collection_status.setText(f'Collection ended: {n:,} records saved. Start resumes if below target.')
        self.cancelled.clear(); self.busy(True,True)
        self.task=Task(work); self.task.progress.connect(self.collection_progress)
        self.task.result.connect(done); self.task.error.connect(self.report_error)
        self.task.finished.connect(self.task_finished); self.task.start()
    def collection_progress(self,n,message): self.progress.setValue(n); self.collection_status.setText(message)
    def pause_collection(self):
        self.collector.pause(); self.collection_status.setText('Pause requested; waiting for active request to finish.')
        self.pause_button.setEnabled(False); self.resume_button.setEnabled(True)
    def resume_collection(self):
        self.collector.resume(); self.pause_button.setEnabled(True); self.resume_button.setEnabled(False)
        self.collection_status.setText('Resumed')
    def stop_collection(self):
        self.collector.stop(); self.collection_status.setText('Stopping; committed records are retained.')
        self.pause_button.setEnabled(False); self.resume_button.setEnabled(False); self.stop_button.setEnabled(False)
    def closeEvent(self,event):
        if self.task and self.task.isRunning():
            self.cancelled.set()
            if self.collector: self.collector.stop()
            self.status.setText('Stopping active task. Close again after it finishes.'); event.ignore()
        else: event.accept()

def configure_style(app):
    app.setStyle('Fusion')
    app.setStyleSheet('''QWidget {font-family: "Segoe UI", Arial; font-size: 12px;}
        QMainWindow {background: #f3f6fb;} QLabel#hero {font-size: 29px; font-weight: 700; color: #13334c;}
        QPushButton {padding: 7px 12px; border: 1px solid #bdcbd9; border-radius: 5px; background: #fff;}
        QPushButton:hover {background: #deedf7;} QPushButton:disabled {color: #98a5af;}
        QLineEdit,QComboBox,QSpinBox {padding: 5px;}
        QTabBar::tab {padding: 11px 21px;} QTabBar::tab:selected {color:#075f80; font-weight:600;}
        QHeaderView::section {background: #e5edf5; padding: 6px; border: 0;}
        QProgressBar::chunk {background:#1282a2;}''')

def main():
    app=QApplication(sys.argv)
    configure_style(app)
    window=Window(); window.show(); sys.exit(app.exec())

if __name__=='__main__': main()
