"""Reproduce the bundled single-run benchmark CSVs."""
import csv
import platform
from dataclasses import asdict
from algorithms import INFO,sort_records
from data_layer import load_rows

def measure(rows,names,path):
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=['algorithm','records','column','direction','milliseconds','comparisons','swaps','writes','stable','python','platform'])
        w.writeheader()
        for name in names:
            result,m=sort_records(rows,name,[('citations',False)])
            assert all(result[i]['citations']<=result[i+1]['citations'] for i in range(len(result)-1))
            w.writerow(dict(algorithm=name,records=len(rows),column='citations',direction='ascending',**asdict(m),stable=INFO[name][1],python=platform.python_version(),platform=platform.platform()))
if __name__=='__main__':
    rows=load_rows()
    measure(rows[:500],list(INFO),'docs/benchmark_500.csv')
    measure(rows,['Merge','Quick','Heap','Shell','Comb','Counting','Radix'],'docs/benchmark_full.csv')
