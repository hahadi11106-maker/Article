# ArticleLab — CS200 Project 1

A Python / PyQt6 desktop project for collecting, exploring, searching, sorting,
and benchmarking journal-article metadata. Prepared against the supplied Fall
2026 CS200 guidelines (deadline in the brief: 18 October 2026).

## Run on Windows

1. Install Python 3.10 or newer with the Python launcher enabled.
2. Extract this entire ZIP to a writable folder.
3. Double-click `run_windows.bat`. The first launch needs internet to install PyQt6.
4. The included database loads automatically. Internet is not required to explore it.

Manual installation (Windows, macOS, Linux):

```sh
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS / Linux:
# source .venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```

Linux needs a working desktop environment and Qt system dependencies. For headless
testing only, set `QT_QPA_PLATFORM=offscreen`. `run.sh` automates a local virtual
environment on macOS/Linux. This is source code, not a compiled Windows EXE.

## Included files

- `app.py`: desktop UI, table model, background jobs and event handling.
- `algorithms.py`: 12 handwritten sorting implementations and instrumentation.
- `searching.py`: linear composite filters and exact binary search.
- `data_layer.py`: collection, SQLite checkpointing, CSV import/export and CLI.
- `data/articles.db`: real Europe PMC article metadata, ready to use.
- `data/articles.csv`: portable copy of the same records.
- `data/manifest.json`: count, query, collection timestamp and field completeness.
- `data/collection.log`: collection progress, not fabricated sample records.
- `docs/PROJECT_REPORT.md` and `.pdf`: design, requirement mapping and viva guide.
- `docs/benchmark_500.csv`: measured comparison of all algorithms on 500 rows.
- `docs/benchmark_full.csv`: measured efficient algorithms on the complete dataset.
- `docs/screenshot.png`: actual rendered desktop UI.
- `docs/VALIDATION.txt`: executed test results.
- `tests/`: automated core and desktop smoke checks.

## Important scope notes

**Collection uses the official Europe PMC REST API, not HTML scraping.** Confirm
with your instructor that this meets their use of the word "scrapping". If they
require parsing HTML, the collector must be adapted before submission. The URL
bonus is supported for Europe PMC search API URLs only, not arbitrary websites.

The brief does not list algorithms taught in class. This project includes Bubble,
Selection, Insertion, Merge, Quick, Heap, Shell, Cocktail, Comb, Gnome, Counting and
Radix. Compare this list with your class syllabus. Comb and Gnome are designated
additional algorithms, but count as extras only if they were not already taught.

The project is an individual assignment. Read and understand the code, personalize
the report, and follow your course's rules for acknowledging assistance.

## Use the application

### Explore and search

Use **+ Filter** to add a clause; choose its column, operator and value. Blank
values are ignored. Choose global AND or OR. Tick NOT to negate an individual
clause. Strings are compared without case sensitivity. Numeric columns use integer
comparisons. Filters always start from the loaded full dataset.

Example: `journal contains medicine AND NOT year < 2020`.

Linear filtering supports contains, starts with, ends with, equals, not equals,
and ordered comparisons. Binary exact search accepts one non-negated equals
clause and returns every duplicate match. Its Merge-sort index time and binary
lookup time are shown separately. The index is rebuilt for each search.

### Sorting

Click a column header to select it as the sole sort key, or use the sort-key rows.
Choose ascending/descending for each key. The first key has highest priority.
Choose an algorithm and click Sort. Metrics appear at the bottom of the window.

- Filtered results: reorders the current visible subset only.
- Full dataset: reorders all loaded records, then reapplies the current filter.
- Sorting does not rewrite the SQLite database. Export visible CSV to save a view.
- Counting and Radix work on a single integer column, year or citations.
- Counting refuses a key span above 1,000,000 to bound allocation.
- Equal strings are normalized using casefold; original display text is preserved.

### Benchmark

Benchmark all runs every applicable algorithm on exactly the same input snapshot
and selected sort keys. Incompatible algorithms are marked N/A with a reason.
There is no automatic sampling. Full-data quadratic sorts can take minutes;
use a filtered subset first. Cancel retains finished benchmark rows. Export
results from the Benchmark tab when the task has ended.

### Collect, pause and resume

The bundled database already contains the assignment dataset. To demonstrate
collection, choose a NEW `.db` file in the Collect tab, set a target (e.g. 2,000),
and press Start. Pause stops at a safe request boundary; Resume continues. Stop
retains all committed pages. Start after Stop or after reopening the app resumes
from the saved cursor. Increase the target above the existing count to collect more.

The URL must use this endpoint and include a `query` parameter:

`https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=OPEN_ACCESS:Y`

Changing the query requires another database. Each record is unique by source
plus article ID. A completed page and its cursor are committed together. Network
errors retry with backoff and leave the last checkpoint intact. Long-lived API
cursors are controlled by the upstream service; if one becomes invalid, collect
into a new database. Queries with too few matches report source exhaustion.

CLI alternative:

```sh
python data_layer.py --target 15000 --database data/my_collection.db
```

### Test

From the project root:

```sh
python -m unittest discover -s tests -p "test_*.py" -v
python tests/gui_smoke.py
```

The smoke test requires PyQt6 and the included 15,000-record database. It uses an
offscreen window and writes a screenshot. Unit tests use controlled mock responses
for restart, duplicate handling and query isolation; no network is needed.

## Metric definitions

Elapsed milliseconds include the input-list copy, normalized key preparation and
algorithm execution; they exclude UI rendering and file I/O. A key comparison
counts once for each examined sort-key component. A swap exchanges two distinct
positions. Writes include array/output placement and temporary merge/bucket
placement, but not the initial copy. Merge and distribution sorts can have zero
swaps while doing substantial work. Counting/Radix comparisons count min/max key
comparisons, not bucket-index calculations. These counters describe implementation
work, not equivalent units of CPU cost. Times vary by hardware and input order.

## Data source

Europe PMC, Articles RESTful API:
https://europepmc.org/RestfulWebService

Documentation and cursor pagination reference:
https://europepmc.org/docs/EBI_Europe_PMC_Web_Service_Reference.pdf

Only article metadata is included, not full-text articles or images. Retain source
attribution and check Europe PMC/source terms before redistributing outside your
course. Blank optional fields reflect upstream metadata; missing numeric fields
are normalized to zero. Citation counts are a collection-time snapshot.
