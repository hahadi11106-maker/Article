"""Transactional Europe PMC collection, durable resume and CSV interchange."""
import csv
import json
import sqlite3
import threading
import urllib.parse
import urllib.request
from pathlib import Path
from datetime import datetime, timezone

COLUMNS = ['article_id','title','authors','journal','year','citations','doi',
           'source','open_access','first_publication_date','pmcid']
NUMERIC = {'year','citations'}
DEFAULT_URL = 'https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=OPEN_ACCESS:Y%20AND%20FIRST_PDATE:[2000-01-01%20TO%202026-10-05]'
DEFAULT_DB = Path(__file__).resolve().parent/'data'/'articles.db'

def connect(path=DEFAULT_DB):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(str(path), timeout=30)
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('CREATE TABLE IF NOT EXISTS articles (' + ','.join(
        k + (' INTEGER' if k in NUMERIC else ' TEXT') for k in COLUMNS) + ', PRIMARY KEY(source,article_id))')
    c.execute('CREATE TABLE IF NOT EXISTS state (key TEXT PRIMARY KEY, value TEXT)')
    return c

def load_rows(path=DEFAULT_DB):
    with connect(path) as c:
        c.row_factory = sqlite3.Row
        return [dict(r) for r in c.execute('SELECT * FROM articles ORDER BY rowid')]

def export_csv(rows, path):
    with open(path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=COLUMNS)
        writer.writeheader(); writer.writerows(rows)

def import_csv(path):
    with open(path, newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or not set(COLUMNS).issubset(reader.fieldnames):
            raise ValueError('CSV needs columns: '+', '.join(COLUMNS))
        rows, seen = [], set()
        for r in reader:
            row = {k: int(r[k]) if k in NUMERIC else r[k] or '' for k in COLUMNS}
            identity = row['source'], row['article_id']
            if identity in seen: continue
            seen.add(identity); rows.append(row)
        return rows

def parse_url(url):
    p = urllib.parse.urlparse(url)
    if p.scheme != 'https' or p.hostname != 'www.ebi.ac.uk' or p.path.rstrip('/') != '/europepmc/webservices/rest/search':
        raise ValueError('Use an HTTPS Europe PMC search API URL (www.ebi.ac.uk). Arbitrary websites are not supported.')
    query = urllib.parse.parse_qs(p.query).get('query', [''])[0]
    if not query.strip(): raise ValueError('URL must include a non-empty query parameter.')
    return 'https://www.ebi.ac.uk/europepmc/webservices/rest/search', query

class Collector:
    """Pause/stop are cooperative; an in-flight HTTP request can take 30 seconds.
    A completed page and its next cursor commit in ONE transaction. A stopped
    request's uncommitted response is discarded, so resume never skips a page.
    """
    def __init__(self, path=DEFAULT_DB):
        self.path = path
        self.gate = threading.Event(); self.gate.set()
        self.stopped = threading.Event()
    def pause(self): self.gate.clear()
    def resume(self): self.gate.set()
    def stop(self): self.stopped.set(); self.gate.set()
    def wait_ready(self):
        while not self.stopped.is_set():
            if self.gate.wait(.1): return True
        return False
    def run(self, url, target=15000, progress=lambda n, msg: None):
        endpoint, query = parse_url(url)
        if target < 1: raise ValueError('Target must be positive.')
        c = connect(self.path)
        try:
            state = dict(c.execute('SELECT key,value FROM state'))
            if state.get('query') and state['query'] != query:
                raise ValueError('This database belongs to a different query. Select a new database file.')
            count = c.execute('SELECT count(*) FROM articles').fetchone()[0]
            cursor = state.get('cursor', '*')
            if state.get('exhausted') == 'true' and count < target:
                progress(count, 'Source exhausted; select a broader query in a new database.'); return count
            while count < target and self.wait_ready():
                params = dict(query=query, format='json', resultType='lite',
                              pageSize=min(1000, target-count), cursorMark=cursor)
                request_url = endpoint+'?'+urllib.parse.urlencode(params)
                payload = None
                for attempt in range(4):
                    if not self.wait_ready(): return count
                    try:
                        req = urllib.request.Request(request_url, headers={'User-Agent':'ArticleLab-Educational/1.0'})
                        with urllib.request.urlopen(req, timeout=30) as response:
                            payload = json.load(response)
                        break
                    except (OSError, ValueError) as exc:
                        if attempt == 3: raise RuntimeError('Collection failed; checkpoint retained: '+str(exc)) from exc
                        progress(count, f'Retrying request ({attempt+1}/3)...')
                        if self.stopped.wait(2**attempt): return count
                if not self.wait_ready(): return count
                results = payload.get('resultList', {}).get('result', [])
                next_cursor = payload.get('nextCursorMark')
                records = []
                for r in results:
                    def integer(v):
                        try: return int(v)
                        except (TypeError, ValueError): return 0
                    records.append((str(r.get('id','')), r.get('title',''), r.get('authorString',''),
                        r.get('journalTitle',''), integer(r.get('pubYear')), integer(r.get('citedByCount')),
                        r.get('doi',''), r.get('source',''), r.get('isOpenAccess','N'),
                        r.get('firstPublicationDate',''), r.get('pmcid','')))
                exhausted = not results or not next_cursor or next_cursor == cursor
                now = datetime.now(timezone.utc).isoformat()
                with c:
                    c.executemany('INSERT OR IGNORE INTO articles VALUES ('+','.join('?' for _ in COLUMNS)+')', records)
                    updates = {'query':query, 'cursor':next_cursor or cursor, 'url':url,
                               'updated_utc':now, 'exhausted':json.dumps(exhausted)}
                    c.executemany('INSERT OR REPLACE INTO state VALUES (?,?)', updates.items())
                cursor = next_cursor or cursor
                count = c.execute('SELECT count(*) FROM articles').fetchone()[0]
                progress(count, 'Source exhausted' if exhausted else f'Collected {count:,} articles')
                if exhausted: break
                if self.stopped.wait(.25): break
            return count
        finally: c.close()

if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--target', type=int, default=15000)
    p.add_argument('--url', default=DEFAULT_URL)
    p.add_argument('--database', default=str(DEFAULT_DB))
    args = p.parse_args()
    try: Collector(args.database).run(args.url, args.target, lambda n,s: print(s, flush=True))
    except KeyboardInterrupt: print('Interrupted. Last committed page is safe; rerun to resume.')
