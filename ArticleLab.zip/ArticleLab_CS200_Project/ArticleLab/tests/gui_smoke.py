"""Headless smoke test; no internet needed. Run from project root."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import sys
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from PyQt6.QtWidgets import QApplication
from PyQt6.QtTest import QTest
from app import Window, configure_style
app=QApplication([])
configure_style(app)
w=Window(); w.show(); app.processEvents()
assert w.model.rowCount()==len(w.rows)
assert len(w.rows)>=15000, 'Bundled data has fewer than 15,000 records'
def wait_task():
    for _ in range(1000):
        app.processEvents(); QTest.qWait(10)
        if not w.task.isRunning():
            app.processEvents(); return
    raise AssertionError('Worker did not finish')
w.filters.cellWidget(0,0).setCurrentText('citations')
w.filters.cellWidget(0,1).setCurrentText('>=')
w.filters.cellWidget(0,2).setText('1')
w.search(); wait_task(); assert w.visible and all(r['citations']>=1 for r in w.visible)
w.algorithm.setCurrentText('Merge'); w.sort(); wait_task()
assert [r['citations'] for r in w.visible]==sorted(r['citations'] for r in w.visible)
w.clear_search()
w.grab().save('docs/screenshot.png')
w.visible=w.rows[:80]; w.refresh(); w.benchmark(); wait_task()
assert w.bench.rowCount()==12
assert all(w.bench.item(i,7).text()=='Complete' for i in range(12))
w.close(); print('GUI smoke passed: load, filter, sort, benchmark, screenshot, close')
