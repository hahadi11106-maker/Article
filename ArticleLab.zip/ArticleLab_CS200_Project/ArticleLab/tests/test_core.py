import random
import tempfile
import unittest
import threading
import json
import io
from pathlib import Path
from unittest.mock import patch
from algorithms import sort_records, INFO, Cancelled
from searching import filter_rows, binary_search
from data_layer import Collector, load_rows, parse_url, DEFAULT_URL, COLUMNS, export_csv, import_csv

class SortingTests(unittest.TestCase):
    def test_numeric_all_algorithms_both_directions(self):
        rng=random.Random(42)
        cases=[[],[1],[2,2,2],list(range(50)),list(range(49,-1,-1)),[rng.randint(-10,10) for _ in range(100)]]
        for name in INFO:
            for values in cases:
                for desc in (False,True):
                    with self.subTest(name=name,values=values[:3],desc=desc):
                        rows=[{'year':v,'i':i} for i,v in enumerate(values)]
                        result,m=sort_records(rows,name,[('year',desc)])
                        self.assertEqual([r['year'] for r in result],sorted(values,reverse=desc))
                        self.assertEqual(values,[r['year'] for r in rows])
                        if INFO[name][1]:
                            self.assertEqual(result,sorted(rows,key=lambda r:r['year'],reverse=desc))
                        self.assertGreaterEqual(m.milliseconds,0)
    def test_strings_and_multikey(self):
        rows=[{'title':'B','year':1},{'title':'a','year':2},{'title':'A','year':1},{'title':'a','year':2}]
        for name in INFO:
            if name in ('Counting','Radix'): continue
            result,_=sort_records(rows,name,[('title',False),('year',True)])
            self.assertEqual([(r['title'].casefold(),r['year']) for r in result], [('a',2),('a',2),('a',1),('b',1)])
    def test_cancellation_and_domain(self):
        for name in INFO:
            with self.assertRaises(Cancelled): sort_records([{'year':1}],name,[('year',False)],lambda:True)
        for name in ('Counting','Radix'):
            with self.assertRaises(ValueError): sort_records([{'title':'x'}],name,[('title',False)])
    def test_metrics_tiny_case(self):
        _,m=sort_records([{'year':2},{'year':1}],'Bubble',[('year',False)])
        self.assertEqual((m.comparisons,m.swaps,m.writes),(1,1,2))

class SearchTests(unittest.TestCase):
    def setUp(self):
        self.rows=[{'title':'Alpha biology','year':2020},{'title':'Beta BIOLOGY','year':2021},{'title':'Gamma','year':2021}]
    def test_boolean_filters(self):
        result,_=filter_rows(self.rows,[('title','contains','biology',False),('year','equals','2020',True)],'AND')
        self.assertEqual(result,[self.rows[1]])
        result,_=filter_rows(self.rows,[('title','starts with','alpha',False),('title','ends with','mma',False)],'OR')
        self.assertEqual(result,[self.rows[0],self.rows[2]])
    def test_binary_duplicates_empty_missing(self):
        result,m=binary_search(self.rows,'year','2021'); self.assertEqual(result,self.rows[1:])
        self.assertEqual(binary_search([],'year','2020')[0],[])
        self.assertEqual(binary_search(self.rows,'title','missing')[0],[])
        self.assertEqual(binary_search(self.rows,'title','BETA biology')[0],[self.rows[1]])

class CollectionTests(unittest.TestCase):
    def test_checkpoint_resume_and_deduplication(self):
        with tempfile.TemporaryDirectory() as folder:
            db=Path(folder)/'test.db'
            def response(ids,cursor):
                return io.BytesIO(json.dumps({'resultList':{'result':[{'id':str(i),'source':'MED','pubYear':'2020'} for i in ids]},'nextCursorMark':cursor}).encode())
            collector=Collector(db)
            with patch('urllib.request.urlopen',return_value=response([1,2],'next')):
                collector.run(DEFAULT_URL,4,lambda n,s:collector.stop())
            self.assertEqual(len(load_rows(db)),2)
            with patch('urllib.request.urlopen',side_effect=[response([2,3],'next2'),response([4],'next3')]) as http:
                Collector(db).run(DEFAULT_URL,4)
                self.assertIn('cursorMark=next',http.call_args_list[0].args[0].full_url)
            self.assertEqual(len(load_rows(db)),4)
            with self.assertRaises(ValueError): Collector(db).run(DEFAULT_URL.replace('OPEN_ACCESS:Y','cancer'),6)
    def test_pause_resume_stop(self):
        c=Collector(); c.pause(); done=[]
        t=threading.Thread(target=lambda:done.append(c.wait_ready())); t.start()
        self.assertFalse(c.gate.is_set()); c.resume(); t.join(1); self.assertEqual(done,[True])
        c.stop(); self.assertFalse(c.wait_ready())
    def test_url_validation(self):
        for url in ('http://www.ebi.ac.uk/europepmc/webservices/rest/search?query=x','https://example.com/?query=x', 'https://www.ebi.ac.uk/europepmc/webservices/rest/search'):
            with self.assertRaises(ValueError): parse_url(url)
    def test_csv_roundtrip(self):
        with tempfile.TemporaryDirectory() as folder:
            r={k: '' for k in COLUMNS}; r.update(article_id='1',title='A, "B"\nC',year=2020,citations=2,source='MED')
            path=Path(folder)/'test.csv'; export_csv([r],path); self.assertEqual(import_csv(path),[r])

if __name__=='__main__': unittest.main(verbosity=2)
